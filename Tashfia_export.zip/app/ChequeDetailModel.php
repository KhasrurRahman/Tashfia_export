<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ChequeDetailModel extends Model
{
    protected $table = 'cheque_details';
}
