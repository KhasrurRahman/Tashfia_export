<footer class="footer">
    <div class="w-100 clearfix">
        <span class="text-center text-sm-left d-md-inline-block">
        	{{ __('Copyright © '.date("Y").' |  All rights reserved by Sukhtara International Ltd')}}
        </span>
    </div>
</footer>
