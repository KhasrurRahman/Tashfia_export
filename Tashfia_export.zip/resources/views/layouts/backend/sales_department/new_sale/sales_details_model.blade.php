<div class="modal fade" id="sales_details" tabindex="-1" role="dialog" aria-labelledby="sales_detailsTitle"
     aria-hidden="true">
    <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="sales_detailsTitle">Sales Invoice</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body" id="sales_details_model_content">
            </div>
        </div>
    </div>
</div>
