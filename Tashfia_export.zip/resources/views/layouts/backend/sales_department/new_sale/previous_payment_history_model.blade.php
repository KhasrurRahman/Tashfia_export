<div class="modal fade" id="previous_payment_histoty" tabindex="-1" role="dialog" aria-labelledby="previous_payment_histotyTitle"
     aria-hidden="true">
    <div class="modal-dialog" role="document" style="max-width: 90% !important;">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="previous_payment_histotyTitle">Previous Payments Information :</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body" id="sales_details_model_content">
                <table class="table yajra-datatable" style="width: 100%">
                    <thead>
                    <tr>
                        <th>Id</th>
                        <th>Customer</th>
                        <th>Total Unit Price</th>
                        <th>Quantity Of Sell</th>
                        <th>Payment Type</th>
                        <th>Due</th>
                        <th>Date</th>
                        <th>Action</th>
                    </tr>
                    </thead>
                    <tbody>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
