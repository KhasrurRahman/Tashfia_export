<div class="modal fade" id="ingredient" tabindex="-1" role="dialog" aria-labelledby="ingredientTitle"
     aria-hidden="true">
    <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="ingredientTitle">Ingredients Details</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body" id="ingredient_model_content">
                
            </div>
        </div>
    </div>
</div>
