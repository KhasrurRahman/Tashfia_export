@extends('layouts.main')
@section('title', 'Dashboard')
@section('content')
    

    <div class="container-fluid">
    	Dashboard..................
    </div>
	
@endsection