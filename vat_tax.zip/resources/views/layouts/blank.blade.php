@extends('layouts.partial..app')
@section('title','Page_Tile')
@push('css')
@endpush
@section('main_menu','HOME')
@section('active_menu','Page_Tile')
@section('link',route('admin.adminDashboard'))
@section('content')




@endsection
@push('js')
@endpush
