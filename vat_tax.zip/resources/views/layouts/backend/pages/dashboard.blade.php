@extends('layouts.backend.partial.app')
@section('title', 'Dashboard')
@section('content')


    <div class="container-fluid">
    	Dashboard..................
    </div>

@endsection
