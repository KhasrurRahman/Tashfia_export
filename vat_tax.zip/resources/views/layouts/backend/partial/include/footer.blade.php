<footer class="footer">
    <div class="w-100 clearfix">
        <span class="text-center text-sm-left d-md-inline-block">
        	{{ __('Copyright © '.date("Y").' | All Rights Reserved by ')}}
        </span>

        <span class="float-none float-sm-right mt-1 mt-sm-0 text-center footer-copyright" style="margin-top: -60px !important;">

            <div class="col-md-6" style="max-width: 100%">
                A product by<a href="https://vat.alienbdit.com" target="_blank"></a>
            </div>

        </span>
    </div>
</footer>
