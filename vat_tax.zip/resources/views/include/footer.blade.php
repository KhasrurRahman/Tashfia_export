<footer class="footer">
    <div class="w-100 clearfix">
        <span class="text-center text-sm-left d-md-inline-block">
        	{{ __('Copyright © '.date("Y").' | All Rights Reserved by ZIT')}}
        </span>
        <span class="float-none float-sm-right mt-1 mt-sm-0 text-center footer-copyright">
        	A product by
        	<a href="https://vat.alienbdit.com" class="text-dark" target="_blank">
        		ZIT
        	</a>
        </span>
    </div>
</footer>