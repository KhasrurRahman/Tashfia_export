<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class LotDepartmentModel extends Model
{
    protected $table = 'lot_department';

    protected $fillable = ["date","product_id", "quantity", "roll", "lot", "buyer", "sell",'balance'];
    
     public function product()
    {
        return $this->belongsTo(ModelProduct::class,'product_id');
    }
}
